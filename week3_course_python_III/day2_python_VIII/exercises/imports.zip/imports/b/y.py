from a.x import f1x
f1x()




def f1y():
    return f1x()

print(f1y())

def f2y():
    return y2

y1 = "Adios"
y2 = "Agur"