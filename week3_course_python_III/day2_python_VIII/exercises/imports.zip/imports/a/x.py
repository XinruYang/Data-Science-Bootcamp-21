def f1x():
    return "Hola"




def f2x():
    return "Kaixo"



x1 = "Hola"
x2 = "Kaixo"