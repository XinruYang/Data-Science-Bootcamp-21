"COVID-19 DEATH RATE VS. POVERTY: DETAILED ANALISYS"

"The goal of this project is to analyse whether the ratio of higher deaths is related to countries with lower GDP per capita"