import os
print(os.path.abspath("."))